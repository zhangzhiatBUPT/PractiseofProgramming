#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QtNetwork>

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

private:
    Ui::MainWindow *ui;
    QTcpServer* tcp_server;
    QTcpSocket* tcp_socket;

private slots:
    void send_message();
    void recv_message();
    void server_new_connect();
    void socket_disconnect();
    void save_message();
};

#endif // MAINWINDOW_H
