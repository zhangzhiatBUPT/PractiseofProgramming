#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QDateTime>
#include <QFileInfo>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    tcp_server = new QTcpServer();      //建立服务器

    connect(tcp_server,&QTcpServer::newConnection,this,&MainWindow::server_new_connect);        //当有链接请求时，调用用于建立链接的函数

    //实现三个按钮的信号与槽的关联
    connect(ui->pushButton,&QPushButton::clicked,this,&MainWindow::send_message);
    connect(ui->pushButton_2,&QPushButton::clicked,this,&MainWindow::socket_disconnect);
    connect(ui->pushButton_3,&QPushButton::clicked,this,&MainWindow::save_message);

    //将发送按钮设置为不可按
    ui->pushButton->setEnabled(false);

    //服务器监听链接请求
    int port = 1234;
    tcp_server->listen(QHostAddress::Any,port);
    qDebug()<<"Server is listening";
}

//析构函数
MainWindow::~MainWindow()
{
    ui->pushButton->setEnabled(false);
    qDebug()<<"Connection dissconnected";
    tcp_server->close();
    tcp_server->deleteLater();
    delete ui;
}

//当有链接请求是，建立TCP链接
void MainWindow::server_new_connect()
{
    tcp_socket = tcp_server->nextPendingConnection();
    connect(tcp_socket,&QTcpSocket::readyRead,this,&MainWindow::recv_message);
    connect(tcp_socket,&QTcpSocket::disconnected,this,&MainWindow::socket_disconnect);
    ui->pushButton->setEnabled(true);
    qDebug()<<"Connection established!";
}

//发送消息
void MainWindow::send_message()
{
    QDateTime current_date_time =QDateTime::currentDateTime();
    QString current_date =current_date_time.toString("yyyy-MM-dd hh:mm:ss");        //将当前时间设置为“年-月-日 时：分：秒”的形式
    if (ui->textEdit->toPlainText()!="")
    {
        QString data = "Server: " + current_date + '\n' + ui->textEdit->toPlainText();

        //发送消息
        tcp_socket->write(data.toLocal8Bit());
        tcp_socket->flush();

        //将发送的消息显示在显示文本框内
        ui->textBrowser->append(data);
        ui->textEdit->clear();
    }
}

//接受消息
void MainWindow::recv_message()
{
    QByteArray buffer;
    buffer = tcp_socket->readAll();
    ui->textBrowser->append(buffer);
}

//断开与客户端的链接
void MainWindow::socket_disconnect()
{
    ui->pushButton->setEnabled(false);
    qDebug()<<"Connection dissconnected";
    tcp_server->close();
    tcp_server->deleteLater();
    delete ui;
}

//将显示文本框里的内容保存在一个文件里
void MainWindow::save_message()
{
    QFile myFile("ChattingData");
    myFile.open(QIODevice::WriteOnly);
    QTextStream outfile(&myFile);
    outfile<<ui->textBrowser->toPlainText();
    myFile.close();
}
