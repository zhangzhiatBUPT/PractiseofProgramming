#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QFileInfo>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    tcp_socket = new QTcpSocket(this);      //创建客户端套接字

    //实现三个按钮的信号与槽的链接
    connect(ui->pushButton,&QPushButton::clicked,this,&MainWindow::send_message);
    connect(ui->pushButton_2,&QPushButton::clicked,this,&MainWindow::socket_disconnect);
    connect(ui->pushButton_3,&QPushButton::clicked,this,&MainWindow::save_message);

    connect(tcp_socket,&QTcpSocket::readyRead,this,&MainWindow::recv_message);
    connect(tcp_socket,&QTcpSocket::disconnected,this,&MainWindow::socket_disconnect);

    ui->pushButton->setEnabled(false);      //设置发送按钮不可按

    QString IP = "127.0.0.1";
    int port = 1234;

    //向IP地址为“127.0.0.1”，端口号为“1234”发送链接请求
    tcp_socket->abort();
    tcp_socket->connectToHost(IP,port);

    if(!tcp_socket->waitForConnected(30000))
    {
        qDebug() << "Connection failed!";
    }else
    {
        qDebug() << "Connect successfully!";
        ui->pushButton->setEnabled(true);       //成功建立链接时，设置发送按钮可按
    }

}

//析构函数
MainWindow::~MainWindow()
{
    ui->pushButton->setEnabled(false);
    qDebug()<<"Connection dissconnected";
    delete ui;
}

//发送消息
void MainWindow::send_message()
{
    QDateTime current_date_time =QDateTime::currentDateTime();
    QString current_date =current_date_time.toString("yyyy-MM-dd hh:mm:ss");        //将当前时间设置为“年-月-日 时：分：秒”的形式
    if (ui->textEdit->toPlainText()!="")
    {
        QString data = "Client: " + current_date + '\n' + ui->textEdit->toPlainText();
        tcp_socket->write(data.toLocal8Bit());
        tcp_socket->flush();
        ui->textBrowser->append(data);
        ui->textEdit->clear();
    }
}

//接受消息
void MainWindow::recv_message()
{
    QByteArray buffer;
    buffer = tcp_socket->readAll();
    if(!buffer.isEmpty())
    {
        ui->textBrowser->append(buffer);
    }
}

//断开与服务端的链接
void MainWindow::socket_disconnect()
{
    ui->pushButton->setEnabled(false);
    qDebug()<<"Connection dissconnected";
    delete ui;
}

//将显示文本框的内容保存在一个文件里
void MainWindow::save_message()
{
    QFile myFile("ChattingData");
    myFile.open(QIODevice::WriteOnly);
    QTextStream outfile(&myFile);
    outfile<<ui->textBrowser->toPlainText();
    myFile.close();
}
