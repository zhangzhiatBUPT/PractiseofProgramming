#coding=utf-8
import wx, socket, time, threading, sys

reload(sys)
sys.setdefaultencoding('utf8')

# 用户端建立套接字，并请求连接至服务端
s = socket.socket()
host = socket.gethostname()
port = 4321
s.connect((host, port))
print 'Connection established'


def main():

    s.send('test'.encode('utf-8'))
    print(s.recv(1024).decode('utf-8'))
    nickname = raw_input('Notice: Input your nickname: ')
    #nickname = 'test'
    s.sendall(nickname.encode('utf-8'))

    # 发送消息
    def send_mssg(event):
        user_input = contents_input.GetValue()
        if user_input:
            message = nickname+': ' + time.strftime("%Y-%m-%d %H:%M:%S ", time.localtime()) + '\n ' + user_input + '\n'
            try:
                s.send(message.encode('utf-8'))
            except:
                print 'Warning: CONNECTION DROPEED'
            history_dialog.AppendText(message)
            contents_input.Clear()

    # 接收消息
    def recv_mssg():
        try:
            recv_message = s.recv(1024).decode('utf-8')
        except (OSError, socket.error):
            print 'Warning: SERVER ERROR'
        else:
            if recv_message:
                name, time1, time2, recv_contents = recv_message.split(' ', 3)
                message = name + ' ' + time.strftime("%Y-%m-%d %H:%M:%S ", time.localtime()) + recv_contents
                history_dialog.AppendText(message)
            else:
                pass
            timer = threading.Timer(0.1, recv_mssg)
            timer.setDaemon(True)
            timer.start()

    # 关闭窗口
    def close(event):
        s.close()
        sys.exit()

    # 保存聊天记录
    def save(event):
        file = open(u'聊天记录.txt', 'w')
        file.write(history_dialog.GetValue().encode('utf-8'))
        file.close()



    # 基于wxPython设计GUI
    app = wx.App()
    win = wx.Frame(None, title='聊天室')  # 创建窗口框架

    bkg = wx.Panel(win)  # 创建背景组件

    # 创建显示文本框与输入文本框
    history_dialog = wx.TextCtrl(bkg, style=wx.TE_READONLY | wx.TE_MULTILINE | wx.HSCROLL)
    contents_input = wx.TextCtrl(bkg, style=wx.TE_MULTILINE | wx.HSCROLL)

    # 创建一个发送按钮，当按下按钮时发送消息
    SendButton = wx.Button(bkg, label='发送')
    SendButton.Bind(wx.EVT_BUTTON, send_mssg)
    accelTbl = wx.AcceleratorTable([(wx.ACCEL_CTRL, ord('S'), SendButton.GetId())])
    win.SetAcceleratorTable(accelTbl)

    # 创建一个关闭按钮，当按下按钮时关闭窗口
    CloseButton = wx.Button(bkg, label='关闭')
    CloseButton.Bind(wx.EVT_BUTTON, close)

    # 创建一个保存按钮，当按下按钮时保存聊天记录
    SaveButton = wx.Button(bkg,label='保存')
    SaveButton.Bind(wx.EVT_BUTTON, save)

    # 创建一个水平尺寸器，将上述三个按钮放入同一水平位置
    h1box = wx.BoxSizer()
    h1box.AddSpacer(size=100)
    h1box.Add(SendButton, proportion=0, flag=wx.EXPAND | wx.RIGHT | wx.ALIGN_RIGHT, border=5)
    h1box.Add(SaveButton, proportion=0, flag=wx.EXPAND | wx.RIGHT | wx.ALIGN_RIGHT, border=5)
    h1box.Add(CloseButton, proportion=0, flag=wx.EXPAND | wx.RIGHT | wx.ALIGN_RIGHT, border=5)

    # 创建一个垂直尺寸器，设置整个对话框布局
    v1box = wx.BoxSizer(wx.VERTICAL)
    v1box.Add(history_dialog, proportion=2, flag=wx.EXPAND)
    v1box.Add(contents_input, proportion=1, flag=wx.EXPAND)
    v1box.Add(h1box, proportion=0, flag=wx.EXPAND | wx.ALL, border=5)

    bkg.SetSizer(v1box)
    win.Show()

    # 开启线程接收消息
    timer = threading.Timer(0.1, recv_mssg)
    timer.setDaemon(True)
    timer.start()

    app.MainLoop()


if __name__ == '__main__':
    main()