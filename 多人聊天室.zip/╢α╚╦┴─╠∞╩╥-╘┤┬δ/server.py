# coding=utf-8
import wx, socket, time, threading, sys

reload(sys)
sys.setdefaultencoding('utf8')

# 服务器端创建套接字
s = socket.socket()
host = socket.gethostname()
port = 4321
s.bind((host, port))
s.listen(5)

print 'Server is listening...'

userdict = dict()
userlist = list()

def tell(exceptUser, content):
    for ul in userlist:
        if ul.fileno() != exceptUser:
            try:
                ul.sendall(content.encode('utf-8'))
            except:
                pass

def serverFunc(newConnection, connectionNum):
    nickname = newConnection.recv(1024).decode('utf-8')
    userdict[newConnection.fileno()] = nickname
    userlist.append(newConnection)
    tell(connectionNum, 'Notice: '+time.strftime("%Y-%m-%d %H:%M:%S ", time.localtime()) +'\n'+userdict[connectionNum]+' 加入了聊天室 \n')
    while True:
        try:
            recvContent = newConnection.recv(1024).decode('utf-8')
            if recvContent:
                tell(connectionNum, userdict[connectionNum] + ': ' +recvContent )
        except (OSError,socket.error):
            try:
                userlist.remove(newConnection)
            except:
                pass
            tell(connectionNum, 'Notcie: '+time.strftime("%Y-%m-%d %H:%M:%S ", time.localtime())+'\n'+userdict[connectionNum]+' 退出了聊天室.'+'\n')
            newConnection.close()
            return


def main():
   while True:
        conn, addr = s.accept()
        print ('Notice: Connect with ',conn.getsockname(),conn.fileno())
        try:
            buf = conn.recv(1024).decode('utf-8')
            if buf == 'test':
                conn.send(u'Notice: Welcome to chatting room!'+'\n')
                t = threading.Thread(target=serverFunc, args=(conn, conn.fileno()))
                t.setDaemon(True)
                t.start()
            else:
                conn.close()
        except KeyboardInterrupt:
            sys.exit()
if __name__ == '__main__':
    main()
